# Bemutató videó és hírlevél

Két külön téma, amire ebben a körben kértél útmutatót. Mindkettő
önállóan elvégezhető, és egyik sem feltétele a másiknak.

---

## 1. A bemutató videó beágyazása

A videó az oldal legtetején, a nyitókép **fölött** jelenik meg, és
magától elindul.

### Miért nem YouTube-ról ágyazzuk be

A YouTube-beágyazás elé a Google saját vezérlőfelületet, logót és a
végén ajánlott videókat tesz — a sajátjait, akár a konkurenciáét. Ezen
felül sütiket helyez el, amihez süti-hozzájárulás kellene, és lassítja
az oldalt. A saját fájl kézben tartható, gyorsabb, és nincs rajta
idegen felirat. Ezért a videót **fájlként** töltjük fel.

### Milyen fájl kell

A felvételed álló (telefonnal készült, 9:16). Ez így jó — nem kell
átvágni fekvőre. Az oldal így kezeli:

- **Telefonon** a videó a teljes szélességet kitölti. Ez az ideális
  eset, erre készült a felvétel.
- **Asztali gépen** a videó középre kerül, a két oldalára pedig
  ugyanannak a felvételnek az **elmosott, felnagyított** állóképe —
  így nem két fekete sáv tátong mellette, hanem a videó folytatásának
  látszik. (Ezt a megoldást használja az Instagram és a TikTok is a
  webes nézetében.)

### Mit készíts elő

Három fájl kell, pontosan ezekkel a nevekkel:

| Fájl | Mi ez | Megjegyzés |
|---|---|---|
| `bemutato.mp4` | maga a felvétel | **kötelező** |
| `bemutato.webm` | ugyanaz, kisebb méretben | ajánlott, de elhagyható |
| `bemutato-poster.jpg` | egy állókép a videóból | **kötelező** — ez látszik, amíg a videó töltődik |

**Méret:** a videó legfeljebb **15–20 másodperc**, és a fájl ne legyen
nagyobb **8–10 megabájtnál**. Ennél hosszabb videót a mobilnetes
látogató nem vár ki, és a Vercel is lassabban szolgálja ki.

Ha a telefonról kijövő fájl ennél nagyobb (gyakran 60–100 MB),
tömörítsd. Telepítés nélkül, böngészőből:

- **cloudconvert.com** → MP4 → MP4, felbontás `1080x1920`, bitráta
  `3000 kbps`. Itt a WebM is legyártható ugyanabból a fájlból.
- **freeconvert.com/video-compressor** → célméret megadható
  közvetlenül (pl. 8 MB).

A poszterképet a legegyszerűbb úgy készíteni, hogy a telefonon
megállítod a videót az első képkockánál, és csinálsz egy képernyőképet
— vagy a fenti oldalakon „MP4 → JPG" átalakítással.

### Feltöltés

A három fájl a `public` mappába megy, a `logo-light.png` mellé.
Codespaces-ben: nyisd meg a `public` mappát a bal oldali fasorban, és
húzd rá a fájlokat.

Utána a Vercelen kapcsold be: **Settings → Environment Variables →
Add New**

```
NEXT_PUBLIC_BEMUTATO_VIDEO = 1
```

Mentés után **Deployments → a legfelső sor jobb szélén „…" →
Redeploy**. A beállítás csak újratelepítés után lép életbe.

### Amit tudni érdemes

- **A videó némán indul.** Ez nem beállítás kérdése: a böngészők a
  hangos automatikus indítást kivétel nélkül tiltják. A videó alatt
  van egy „Hang bekapcsolása" gomb annak, aki kéri.
- Aki a telefonján bekapcsolta a „mozgás csökkentése"
  akadálymentességi beállítást (sokan szédülés miatt), annál a videó
  nem indul magától — ott az állókép és egy indítógomb jelenik meg.
- A videót **bármikor ki tudod venni** az oldalról: állítsd a
  `NEXT_PUBLIC_BEMUTATO_VIDEO` értékét `0`-ra, és telepítsd újra. A
  fájlokat nem kell törölni.

---

## 2. Hírlevél — hogyan érdemes küldeni

### Ami már megvan

A foglalóűrlapon van egy **külön, önkéntes** jelölőnégyzet a
hírlevélre. Ez szándékosan nincs összekötve az ÁSZF elfogadásával: a
GDPR szerint a marketing-hozzájárulás nem lehet a vásárlás feltétele,
és a kettőt nem szabad egy pipába tenni.

A feliratkozók az adatbázisban a `hirlevel_feliratkozok` táblában
gyűlnek, és van egy `hirlevel_cimzettek` nézet, ami csak az **érvényes,
vissza nem vont** címeket adja vissza.

### Hogyan küldj

A rendszer már használ **Resend**-et a visszaigazoló levelekhez, és
ugyanaz a fiók a hírlevélre is jó. Nem kell új szolgáltatást bevezetni.

1. **Supabase → Table Editor → `hirlevel_cimzettek`** → jobb felül
   **Export → CSV**. Ez a lista.
2. **Resend → Audiences** → új névjegyzék → **Import CSV**.
3. **Broadcasts → Create broadcast** → megírod a levelet (van benne
   egyszerű szerkesztő), és kiküldöd.

A Resend ingyenes csomagja havi 3 000 levél. Két faház
vendéglistájával ez évekig elég lesz.

### Mire figyelj

- **Leiratkozó link kötelező** minden levélben. A Resend automatikusan
  beteszi, ha a Broadcast funkciót használod — kézzel összerakott
  levélnél neked kell. Enélkül a küldés jogsértő, és a levelek
  gyorsabban kerülnek spam mappába.
- **Ne küldj címlistát a „Címzett" mezőbe.** Ha több vendég e-mail
  címe egymás számára láthatóvá válik, az adatvédelmi incidens. A
  Broadcast funkció mindenkinek külön levelet küld — ezért használd azt.
- **Ütem:** havi egy levélnél sűrűbben ne. Szezonkezdés, ünnepi
  ajánlat, egy-egy szabad hétvége — ennyi bőven elég.
- **A leiratkozást vezesd át** a Supabase-ben is (`leiratkozott`
  oszlop), hogy a következő exportban már ne szerepeljen.

### Ha később automatizálni akarod

A Resend Audiences API-ból a feliratkozás automatikusan átvihető, így
nem kell CSV-zni. Ez egy fél napos fejlesztés, de csak akkor éri meg,
ha havonta többször küldesz. Addig a kézi export teljesen rendben van.
