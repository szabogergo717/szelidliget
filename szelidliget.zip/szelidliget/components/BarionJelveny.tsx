'use client';

import { useState } from 'react';
import type { Nyelv } from '@/lib/tartalom';

/**
 * A Barion kötelező elfogadóhelyi jelvénye („card strip").
 *
 * A Barion elfogadóhelyi szabályzata előírja, hogy a fizetési módot és
 * az elfogadott kártyatípusokat fel kell tüntetni a weboldalon. Erre a
 * Barion saját, kész képét kell használni — a logót NEM szabad
 * újrarajzolni vagy átszínezni, mert védjegy.
 *
 * A KÉPFÁJL NEM RÉSZE A CSOMAGNAK. Töltsd le a Barion felületéről
 * (Barion fiók → Shops → a boltod → „Barion logó" / brand kit; vagy
 * barion.com/hu/dokumentumok), és tedd ide:
 *
 *     public/barion-card-strip.svg
 *
 * Addig, amíg a fájl nincs ott, ez a komponens nem hagy törött képet:
 * átvált a szöveges változatra, ami ugyanazt az információt közli.
 */

const KEP = '/barion-card-strip.svg';

const SZOVEG: Record<Nyelv, string> = {
  hu: 'Online bankkártyás fizetés: Barion · Mastercard · Maestro · Visa · Visa Electron',
  en: 'Online card payment: Barion · Mastercard · Maestro · Visa · Visa Electron',
};

const ALT: Record<Nyelv, string> = {
  hu: 'Barion — elfogadott bankkártyák: Mastercard, Maestro, Visa, Visa Electron',
  en: 'Barion — accepted cards: Mastercard, Maestro, Visa, Visa Electron',
};

export default function BarionJelveny({
  nyelv,
  helye = 'lablec',
}: {
  nyelv: Nyelv;
  /** `lablec`: halvány háttéren, kisebben. `urlap`: a fizetés gomb mellett. */
  helye?: 'lablec' | 'urlap';
}) {
  const [hiba, setHiba] = useState(false);

  return (
    <div className={`barion barion-${helye}`}>
      {hiba ? (
        <span className="barion-szoveg">{SZOVEG[nyelv]}</span>
      ) : (
        /* Sima <img>: a next/image a hiányzó fájlra build hibát adna, és
           egy pár kilobájtos SVG-nél nincs mit optimalizálni. */
        /* eslint-disable-next-line @next/next/no-img-element */
        <img
          src={KEP}
          alt={ALT[nyelv]}
          loading="lazy"
          onError={() => setHiba(true)}
        />
      )}
    </div>
  );
}
